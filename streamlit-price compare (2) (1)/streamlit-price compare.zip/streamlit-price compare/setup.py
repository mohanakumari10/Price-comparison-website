import nltk
nltk.downloader.download('vader_lexicon')
